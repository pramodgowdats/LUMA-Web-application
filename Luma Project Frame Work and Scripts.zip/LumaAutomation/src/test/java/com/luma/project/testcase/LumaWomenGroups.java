package com.luma.project.testcase;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.luma.project.genericutility.BaseClass;
import com.luma.project.pomrepository.ListPageForWomen;
import com.luma.project.pomrepository.LumaCheckoutPage;
import com.luma.project.pomrepository.LumaCustomerSigninPage;
import com.luma.project.pomrepository.LumaHomePage;
import com.luma.project.pomrepository.LumaSignInPage;
import com.luma.project.pomrepository.LumaWomenPage;

public class LumaWomenGroups extends BaseClass {
	@Test(priority = 1, groups = "FunctionalityTesting")
	public void clickOnSignInHomePage() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
	}

	@Test(priority = 2, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnSignInHomePage")
	public void passTheDataForEmailAndPaswd() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
	}

	@Test(priority = 3, groups = { "FunctionalityTesting", "IntegrationTesting" }, dependsOnMethods = {
			"clickOnSignInHomePage", "passTheDataForEmailAndPaswd" })
	public void clickOnSignInAfterDataEntering() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
	}

	@Test(priority = 4, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnSignInAfterDataEntering")
	public void clickOnWomenModule() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
	}

	@Test(priority = 5, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnWomenModule")
	public void clickOnWomenTops() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
	}

	@Test(priority = 6, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnWomenTops")
	public void clickOnList() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
	}

	@Test(priority = 7, groups = { "FunctionalityTesting", "IntegrationTesting" }, dependsOnMethods = "clickOnList")
	public void selectAnyOneOfTheProductAndSelectAnyOneSize() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
	}

	@Test(priority = 8, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "selectAnyOneOfTheProductAndSelectAnyOneSize")
	public void clickOnAnyOneColourOfSelectedProduct() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
	}

	@Test(priority = 9, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnAnyOneColourOfSelectedProduct")
	public void clickOnAddToCart() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();

	}

	@Test(priority = 10, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnAddToCart")
	public void ClickOnMyCart() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
	}

	@Test(priority = 11, groups = { "FunctionalityTesting", "IntegrationTesting" }, dependsOnMethods = "ClickOnMyCart")
	public void clickOnProceedToCheckOutOptionInMyCart() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
	}

	@Test(priority = 12, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnProceedToCheckOutOptionInMyCart")
	public void passTheDataInCheckOutPage() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
		LumaCheckoutPage checkOutPage = new LumaCheckoutPage(driver);
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		// action.scrollToElement(checkOutPage.getFlatRateRadioButton()).perform();
		// checkOutPage.getFlatRateRadioButton().click();//here we get
		// ElementNotClickableException because when we select india in dropdown by
		// default it will only select the flate radio button so if we pass xpath and if
		// we call click method we get ElementNotClickableException
	}

	@Test(priority = 13, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "passTheDataInCheckOutPage")
	public void clickOnNextRadioButtonInCheckOutPage() throws FileNotFoundException, IOException {// next button
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
		LumaCheckoutPage checkOutPage = new LumaCheckoutPage(driver);
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getNextButton());
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
	}

	@Test(priority = 14, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnNextRadioButtonInCheckOutPage")
	public void clickOnLogoInCheckOutPage() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
		LumaCheckoutPage checkOutPage = new LumaCheckoutPage(driver);
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getNextButton());
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		LumaCheckoutPage logo = new LumaCheckoutPage(driver);
		actions.pause(8000).perform();
		logo.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
	}

	@Test(priority = 15, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnLogoInCheckOutPage")
	public void clickOnMyCartInHomePage() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
		LumaCheckoutPage checkOutPage = new LumaCheckoutPage(driver);
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getNextButton());
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		LumaCheckoutPage logo = new LumaCheckoutPage(driver);
		actions.pause(8000).perform();
		logo.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
		LumaHomePage customerWelcomePage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, customerWelcomePage.getCartOption());
		customerWelcomePage.getCartOption().click();
	}

	@Test(priority = 16, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnMyCartInHomePage")
	public void clickOnDeleteOptionInMyCart() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
		LumaCheckoutPage checkOutPage = new LumaCheckoutPage(driver);
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getNextButton());
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		LumaCheckoutPage logo = new LumaCheckoutPage(driver);
		actions.pause(8000).perform();
		logo.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
		LumaHomePage customerWelcomePage = new LumaHomePage(driver);
		actions.pause(3000).perform();
		customerWelcomePage.getCartOption().click();
		actions.pause(3000).perform();
		customerWelcomePage.getRemoveoption().click();
		actions.pause(3000).perform();
		customerWelcomePage.getOkButton().click();
	}

	@Test(priority = 17, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnDeleteOptionInMyCart")
	public void clickOnUserProfileInHomePage() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
		LumaCheckoutPage checkOutPage = new LumaCheckoutPage(driver);
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getNextButton());
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		LumaCheckoutPage logo = new LumaCheckoutPage(driver);
		actions.pause(8000).perform();
		logo.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
		actions.pause(3000).perform();
		LumaHomePage customerWelcomePage = new LumaHomePage(driver);
		actions.pause(3000).perform();
		customerWelcomePage.getCartOption().click();
		actions.pause(3000).perform();
		customerWelcomePage.getRemoveoption().click();
		actions.pause(3000).perform();
		customerWelcomePage.getOkButton().click();
		actions.pause(5000).perform();
		customerWelcomePage.getCustomerWelcomeOption().click();
	}

	@Test(priority = 18, groups = { "FunctionalityTesting", "IntegrationTesting",
			"System Testing" }, dependsOnMethods = "clickOnUserProfileInHomePage")
	public void clickOnUserProfileInHomePageAndClickOnSignOut() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		webdriverUtils.elementToBeClickable(driver, homePage.getSignInOption());
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		webdriverUtils.elementToBeClickable(driver, loginPage.getSignInbutton());
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePage womenPage = new LumaHomePage(driver);
		webdriverUtils.elementToBeClickable(driver, womenPage.getWomenOption());
		womenPage.getWomenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 10, 1)),
				"url is found incorrect after click on women");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 11, 1)),
				"title is found incorrect after click on women");
		LumaWomenPage womenTops = new LumaWomenPage(driver);
		webdriverUtils.elementToBeClickable(driver, womenTops.getTopsOption());
		womenTops.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 12, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 13, 1)),
				"title is found incorrect after click on tops");
		Actions actions = new Actions(driver);
		actions.pause(4000).perform();
		ListPageForWomen topOption = new ListPageForWomen(driver);
		webdriverUtils.elementToBeClickable(driver, topOption.getListOption());
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 14, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 15, 1)),
				"title is found incorrect after click on list");
		webdriverUtils.elementToBeClickable(driver, topOption.getSizeCheckBox());
		topOption.getSizeCheckBox().click();
		webdriverUtils.elementToBeClickable(driver, topOption.getColorCheckBox());
		topOption.getColorCheckBox().click();
		actions.pause(4000).perform();
		topOption.getAddToCartOption().click();
		actions.pause(5000).perform();
		topOption.getCartOption().click();
		actions.pause(3000).perform();
		topOption.getCheckOutOption().click();
		LumaCheckoutPage checkOutPage = new LumaCheckoutPage(driver);
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getNextButton());
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		LumaCheckoutPage logo = new LumaCheckoutPage(driver);
		actions.pause(8000).perform();
		logo.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
		LumaHomePage customerWelcomePage = new LumaHomePage(driver);
		actions.pause(3000).perform();
		customerWelcomePage.getCartOption().click();
		actions.pause(3000).perform();
		customerWelcomePage.getRemoveoption().click();
		actions.pause(3000).perform();
		customerWelcomePage.getOkButton().click();
		actions.pause(5000).perform();
		customerWelcomePage.getCustomerWelcomeOption().click();
		actions.pause(3000).perform();
		customerWelcomePage.getSignOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 3, 1)),
				"url is found in correct after logout");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 2, 1)),
				"title is found in correct after logout");
	}
}