package com.luma.project.testcase;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.luma.project.genericutility.BaseClass;
import com.luma.project.pomrepository.LumaCheckoutPageForMen;
import com.luma.project.pomrepository.LumaCustomerSigninPage;
import com.luma.project.pomrepository.LumaHomePageForMen;
import com.luma.project.pomrepository.LumaListPageForMen;
import com.luma.project.pomrepository.LumaMenPage;
import com.luma.project.pomrepository.LumaSignInPage;
import com.luma.project.pomrepository.LumaTopPageForMen;

public class LumaMenGroups extends BaseClass {
	@Test(priority = 1, groups = "FunctionalityTesting")
	public void clickOnSignInHomePage() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
	}

	@Test(priority = 2, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnSignInHomePage")
	public void passTheDataForEmailAndPaswd() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
	}

	@Test(priority = 3, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "passTheDataForEmailAndPaswd")
	public void clickOnSignInAfterDataEntering() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");

	}

	@Test(priority = 4, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnSignInAfterDataEntering")
	public void clickOnMenModule() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");

	}

	@Test(priority = 5, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnMenModule")
	public void clickOnMenTops() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		LumaMenPage menPage = new LumaMenPage(driver);
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
	}

	@Test(priority = 6, groups = { "FunctionalityTesting", "IntegrationTesting" }, dependsOnMethods = "clickOnMenTops")
	public void clickOnJacketsOptionInCategoryDropDown() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		LumaMenPage menPage = new LumaMenPage(driver);
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		actions.pause(3000).perform();
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");

	}

	@Test(priority = 7, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnJacketsOptionInCategoryDropDown")
	public void clickOnLightWeightOptionInStyleDropDown() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		actions.pause(3000).perform();
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");

	}

	@Test(priority = 8, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnLightWeightOptionInStyleDropDown")
	public void clickOnMOptionInSizeDropDown() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");

	}

	@Test(priority = 9, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnMOptionInSizeDropDown")
	public void clickOnRedOptionInColorDropDown() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
	}

	@Test(priority = 10, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnRedOptionInColorDropDown")
	public void clickOnList() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
	}

	@Test(priority = 11, groups = { "FunctionalityTesting", "IntegrationTesting" }, dependsOnMethods = "clickOnList")
	public void clickOnAddToCart() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
	}

	@Test(priority = 12, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnAddToCart")
	public void clickOnProceedToCheckOut() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
		actions.pause(2000).perform();
		addToCartPage.getCheckOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");

	}

	@Test(priority = 13, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnProceedToCheckOut")
	public void passTheDataCheckOutPage() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
		actions.pause(2000).perform();
		addToCartPage.getCheckOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		LumaCheckoutPageForMen checkOutPage = new LumaCheckoutPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getCompanyTextField());
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(2000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
	}

	@Test(priority = 14, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "passTheDataCheckOutPage")
	public void clickOnNextButton() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
		actions.pause(3000).perform();
		addToCartPage.getCheckOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		LumaCheckoutPageForMen checkOutPage = new LumaCheckoutPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getCompanyTextField());
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(2000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
	}

	@Test(priority = 15, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnNextButton")
	public void clickOnLumaLogo() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(3000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
		actions.pause(2000).perform();
		addToCartPage.getCheckOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		LumaCheckoutPageForMen checkOutPage = new LumaCheckoutPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getCompanyTextField());
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(2000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		actions.pause(5000).perform();
		checkOutPage.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
	}

	@Test(priority = 16, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "clickOnLumaLogo")
	public void toDeleteTheProduct() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
		actions.pause(3000).perform();
		addToCartPage.getCheckOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		LumaCheckoutPageForMen checkOutPage = new LumaCheckoutPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getCompanyTextField());
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(2000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		actions.pause(5000).perform();
		checkOutPage.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
		actions.pause(4000).perform();
		homePage1.getCartOption1().click();
		actions.pause(2000).perform();
		homePage1.getRemoveoption().click();
		actions.pause(2000).perform();
		homePage1.getOkButton().click();
	}

	@Test(priority = 17, groups = { "FunctionalityTesting",
			"IntegrationTesting" }, dependsOnMethods = "toDeleteTheProduct")
	public void toClickOnCustomerWelcome() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(2000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
		actions.pause(2000).perform();
		addToCartPage.getCheckOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		LumaCheckoutPageForMen checkOutPage = new LumaCheckoutPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getCompanyTextField());
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(2000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		actions.pause(5000).perform();
		checkOutPage.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
		actions.pause(4000).perform();
		homePage1.getCartOption1().click();
		actions.pause(2000).perform();
		homePage1.getRemoveoption().click();
		actions.pause(2000).perform();
		homePage1.getOkButton().click();
		actions.pause(3000).perform();
		homePage1.getCustomerWelcomeOption().click();
	}

	@Test(priority = 18, groups = { "FunctionalityTesting", "IntegrationTesting",
			"SystemTesting" }, dependsOnMethods = "toClickOnCustomerWelcome")
	public void toClickOnSignOut() throws FileNotFoundException, IOException {
		LumaSignInPage homePage = new LumaSignInPage(driver);
		homePage.getSignInOption().click();
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 1, 1)),
				"title is found incorrect after click on signin");
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 0, 1)),
				"title is found incorrect after click on signin");
		LumaCustomerSigninPage loginPage = new LumaCustomerSigninPage(driver);
		loginPage.getEmailTextField().sendKeys(fileUtils.readData("email"));
		loginPage.getPasswordTextField().sendKeys(fileUtils.readData("password"));
		loginPage.getSignInbutton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 8, 1)),
				"url is found incorrect after entering data and click on signin");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 9, 1)),
				"url is found incorrect after entering data and click on signin");
		LumaHomePageForMen homePage1 = new LumaHomePageForMen(driver);
		homePage1.getMenOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 20, 1)),
				"url is found incorrect after click on men");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 21, 1)),
				"title is found incorrect after click on men");
		Actions actions = new Actions(driver);
		actions.pause(3000).perform();
		LumaMenPage menPage = new LumaMenPage(driver);
		menPage.getTopsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 22, 1)),
				"url is found incorrect after click on tops");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 23, 1)),
				"title is found incorrect after click on tops");
		actions.pause(3000).perform();
		LumaTopPageForMen topOption = new LumaTopPageForMen(driver);
		topOption.getCategoryOption().click();
		actions.pause(3000).perform();
		topOption.getJacketsOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 26, 1)),
				"url is found incorrect after click on jackets");
		actions.pause(3000).perform();
		topOption.getStyleOption().click();
		actions.pause(3000).perform();
		topOption.getLightWeightOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 27, 1)),
				"url is found incorrect after click on lightweight");
		actions.pause(3000).perform();
		topOption.getSizeOption().click();
		actions.pause(3000).perform();
		topOption.getmSizeOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 28, 1)),
				"url is found incorrect after click on msize");
		actions.pause(3000).perform();
		topOption.getColorOption().click();
		actions.pause(3000).perform();
		topOption.getRedColorOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 29, 1)),
				"url is found incorrect after click on redcolor");
		actions.pause(3000).perform();
		topOption.getListOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 24, 1)),
				"url is found incorrect after click on list");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 25, 1)),
				"title is found incorrect after click on list");
		actions.pause(5000).perform();
		LumaListPageForMen addToCartPage = new LumaListPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, addToCartPage.getAddToCartOption());
		addToCartPage.getAddToCartOption().click();
		actions.pause(4000).perform();
		addToCartPage.getCartOption().click();
		actions.pause(2000).perform();
		addToCartPage.getCheckOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 5, 1)),
				"url is found incorrect in checkout page after click on proceed to checkout button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 4, 1)),
				"title is found incorrect in checkout page after click on proceed to checkout button");
		actions.pause(10000).perform();
		LumaCheckoutPageForMen checkOutPage = new LumaCheckoutPageForMen(driver);
		webdriverUtils.elementToBeClickable(driver, checkOutPage.getCompanyTextField());
		checkOutPage.getCompanyTextField().sendKeys(fileUtils.readData("company"));
		checkOutPage.getStreet1TextField().sendKeys(fileUtils.readData("street1"));
		checkOutPage.getStreet2TextField().sendKeys(fileUtils.readData("street2"));
		checkOutPage.getStreet3TextField().sendKeys(fileUtils.readData("street3"));
		checkOutPage.getCityTextField().sendKeys(fileUtils.readData("city"));
		checkOutPage.getCountryDropdown().click();
		actions.pause(3000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getStateDropdown().click();
		actions.pause(2000).scrollByAmount(0, 300).pause(2000).click().perform();
		checkOutPage.getZipCodeTextField().sendKeys(fileUtils.readData("zipcode"));
		checkOutPage.getPhoneNoTextField().sendKeys(fileUtils.readData("phoneno"));
		checkOutPage.getNextButton().submit();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 16, 1)),
				"url is found incorrect after click on next button");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 17, 1)),
				"title is found incorrect after click on next button");
		actions.pause(5000).perform();
		checkOutPage.getLumaLogoButton().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 18, 1)),
				"url is found incorrect after click on logo in checkout page");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 19, 1)),
				"url is found incorrect after click on logo in checkout page");
		actions.pause(4000).perform();
		homePage1.getCartOption1().click();
		actions.pause(2000).perform();
		homePage1.getRemoveoption().click();
		actions.pause(2000).perform();
		homePage1.getOkButton().click();
		actions.pause(3000).perform();
		homePage1.getCustomerWelcomeOption().click();
		actions.pause(2000).perform();
		homePage1.getSignOutOption().click();
		Assert.assertTrue(webdriverUtils.verifyPartialUrl(driver, excelUtils.readStringData("Sheet2", 3, 1)),
				"url is found in correct after logout");
		Assert.assertTrue(webdriverUtils.verifyCompleteTitle(driver, excelUtils.readStringData("Sheet2", 2, 1)),
				"title is found in correct after logout");

	}
}