package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaSignInPage1 {
  WebDriver driver;
  public LumaSignInPage1(WebDriver driver) {
		this.driver = driver;
	  PageFactory.initElements(driver, this);
	}
  @FindBy(xpath ="//div[@class='panel header']//a[contains(.,'Sign In')]")
  private  WebElement signInOption;
public WebElement getSignInOption() {
	return signInOption;
}
}