package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaListPageForMen {
	WebDriver driver;

	public LumaListPageForMen(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(.,'Montana Wind Jacket')]/ancestor::div[@class='product details product-item-details']/descendant::button[@title='Add to Cart']")
	private WebElement addToCartOption;
	@FindBy(xpath = "//a[@class='action showcart']")
	private WebElement cartOption;
	@FindBy(xpath = "//button[text()='Proceed to Checkout']")
	private WebElement checkOutOption;

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getAddToCartOption() {
		return addToCartOption;
	}

	public WebElement getCartOption() {
		return cartOption;
	}

	public WebElement getCheckOutOption() {
		return checkOutOption;
	}
}