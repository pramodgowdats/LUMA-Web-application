package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaCustomerSigninPage1 {
	WebDriver driver;

	public LumaCustomerSigninPage1(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getEmailIdTextField() {
		return emailIdTextField;
	}

	@FindBy(css = "input[id='email']")
	private WebElement emailIdTextField;

	@FindBy(css = "input[title='Password']")
	private WebElement passwordTextField;

	@FindBy(xpath = "//div[.='Sign In']")
	private WebElement signInbutton;

	public WebElement getEmailTextField() {
		return emailIdTextField;
	}

	public WebElement getPasswordTextField() {
		return passwordTextField;
	}

	public WebElement getSignInbutton() {
		return signInbutton;
	}
}