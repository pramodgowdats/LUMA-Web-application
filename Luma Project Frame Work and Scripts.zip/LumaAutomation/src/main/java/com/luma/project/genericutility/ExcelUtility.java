package com.luma.project.genericutility;


import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
/**
 * @author Pramodgowda T S
 * @param sheetName
 * @param rowIndex
 * @param cellIndex
 * @param stringData
 * @param EncryptedDocumentException
 * @param IOException
 */
public class ExcelUtility {
	public String readStringData(String sheetName, int rowIndex, int cellIndex)
			throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("./src/resources/luma/LumaData.xlsx");
		Workbook workbook = WorkbookFactory.create(fis);
		String data = workbook.getSheet(sheetName).getRow(rowIndex).getCell(cellIndex).getStringCellValue();
		workbook.close();
		return data;
	}

	public double readNumericData(String sheetName, int rowIndex, int cellIndex)
			throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream("./src/resources/luma/LumaData.xlsx");
		Workbook workbook = WorkbookFactory.create(fis);
		double data = workbook.getSheet(sheetName).getRow(rowIndex).getCell(cellIndex).getNumericCellValue();
		workbook.close();
		return data;

	}

}
