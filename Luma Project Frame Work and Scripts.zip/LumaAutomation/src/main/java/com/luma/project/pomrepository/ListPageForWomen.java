package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ListPageForWomen {
	WebDriver driver;

	public ListPageForWomen(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[@title='List']")
	private WebElement listOption;

	public WebElement getListOption() {
		return listOption;
	}

	@FindBy(xpath = "//a[contains(.,'Breathe-Easy')]/ancestor::div[@class='product details product-item-details']/descendant::div[@aria-label='Size']/child::div[@aria-label='XS']")
	private WebElement sizeCheckBox;
	@FindBy(xpath = "//a[contains(.,'Breathe-Easy')]/ancestor::div[@class='product details product-item-details']/descendant::div[@aria-label='Color']/child::div[@aria-label='Purple']")
	private WebElement colorCheckBox;
	@FindBy(xpath = "//a[contains(.,'Breathe-Easy')]/ancestor::div[@class='product details product-item-details']/descendant::button[@title='Add to Cart']")
	private WebElement addToCartOption;
	@FindBy(xpath = "//a[@class='action showcart']")
	private WebElement cartOption;
	@FindBy(xpath = "//button[text()='Proceed to Checkout']")
	private WebElement checkOutOption;
	@FindBy(xpath = "//div[@class='panel wrapper']//li[@class='customer-welcome']")
	private WebElement customerWelcomeOption;
	@FindBy(xpath = "//a[@title='Remove item']")
	private WebElement removeoption;
	@FindBy(xpath = "//button[.='OK']")
	private WebElement okButton;
	@FindBy(xpath = "//div[@class='panel wrapper']//li//ul[@class='header links']//a[contains(.,'Sign Out')]")
	private WebElement signOutOption;

	public WebElement getSizeCheckBox() {
		return sizeCheckBox;
	}

	public WebElement getColorCheckBox() {
		return colorCheckBox;
	}

	public WebElement getAddToCartOption() {
		return addToCartOption;
	}

	public WebElement getCartOption() {
		return cartOption;
	}

	public WebElement getCheckOutOption() {
		return checkOutOption;
	}

	public WebElement getCustomerWelcomeOption() {
		return customerWelcomeOption;
	}

	public WebElement getRemoveoption() {
		return removeoption;
	}

	public WebElement getOkButton() {
		return okButton;
	}

	public WebElement getSignOutOption() {
		return signOutOption;
	}
}
