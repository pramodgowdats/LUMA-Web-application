package com.luma.project.pomrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LumaTopPageForMen {
	WebDriver driver;

	public LumaTopPageForMen(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[text()='Category']")
	private WebElement categoryOption;
	@FindBy(xpath = "//li[@class='item']/a[contains(.,'Jackets')]")
	private WebElement jacketsOption;
	@FindBy(xpath = "//div[text()='Style']")
	private WebElement styleOption;
	@FindBy(xpath = "//li[@class='item']/a[contains(.,'Lightweight')]")
	private WebElement lightWeightOption;
	@FindBy(xpath = "//div[text()='Size']")
	private WebElement sizeOption;
	@FindBy(xpath = "//div[text()='Size']/following-sibling::div[@class='filter-options-content']/descendant::div[text()='M']")
	private WebElement mSizeOption;

	public WebElement getSizeOption() {
		return sizeOption;
	}

	public WebElement getmSizeOption() {
		return mSizeOption;
	}

	public WebElement getColorOption() {
		return colorOption;
	}

	public WebElement getRedColorOption() {
		return redColorOption;
	}

	@FindBy(xpath = "//div[text()='Color']")
	private WebElement colorOption;
	@FindBy(xpath = "//div[text()='Color']/following-sibling::div[@class='filter-options-content']/descendant::div[@option-label='Red']")
	private WebElement redColorOption;
	@FindBy(xpath = "//a[@title='List']")
	private WebElement listOption;

	public WebElement getCategoryOption() {
		return categoryOption;
	}

	public WebElement getJacketsOption() {
		return jacketsOption;
	}

	public WebElement getStyleOption() {
		return styleOption;
	}

	public WebElement getLightWeightOption() {
		return lightWeightOption;
	}

	public WebElement getListOption() {
		return listOption;
	}

}