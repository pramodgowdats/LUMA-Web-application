package com.luma.project.genericutility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
/**
 * 
 * @author Pramodgowda T S
 *
 */
public class FileUtility {
	public String readData(String key) throws FileNotFoundException, IOException {
		Properties pobj = new Properties();
		pobj.load(new FileInputStream("./src/resources/luma/lumadata1.propertiesfiles"));
		String value = pobj.getProperty(key);
		return value;
	}
}
