package com.luma.project.genericutility;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebdriverUtility {
	/**
	 * implicit wait interms of seconds as time limit
	 * 
	 * @param driver
	 */
	public void implicitWaitInSeconds(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(25));
	}
	/**
	 * implicit wait interms of milliseconds as time limit
	 * 
	 * @param driver
	 */
	public void implicitWaitInMillis(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(25));
	}
	/**
	 * wait until verify and validate the complete title of the web page
	 * 
	 * @param Pramodgowda T S
	 * @param exceptedTitle
	 * @return validation in boolean
	 */

	public boolean verifyCompleteTitle(WebDriver driver, String expectedTitle) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		boolean validation = wait.until(ExpectedConditions.titleIs(expectedTitle));
		return validation;
	}
	/**
	 * wait until verify and validate the partial url of the web page
	 * 
	 * @author Pramodgowda T S
	 * @param exceptedUrl
	 * @return validation in boolean
	 */
	public boolean verifyPartialUrl(WebDriver driver, String expectedUrl) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		boolean validation = wait.until(ExpectedConditions.urlContains(expectedUrl));
		return validation;
	}
	/**
	 * To Transfer the driver control to the new window in the same session
	 * 
	 * @author Pramodgowda T S
	 * @param windowId
	 * @param driver
	 * @return WebDriver
	 */
	public WebDriver controlTransferToWindow(WebDriver driver, String windowId) {
		WebDriver updateDriver = driver.switchTo().window(windowId);
		return updateDriver;
	}

	public WebElement elementToBeClickable(WebDriver driver, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));
		WebElement ele = wait.until(ExpectedConditions.elementToBeClickable(element));
		return ele;
	}

	public boolean partialTitle(WebDriver driver, String partialTitle) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		boolean validation = wait.until(ExpectedConditions.titleContains(partialTitle));
		return validation;
	}
}